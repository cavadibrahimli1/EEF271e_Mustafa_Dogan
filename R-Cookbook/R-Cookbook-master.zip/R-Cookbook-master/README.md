# The R Cookbook 2nd Edition

By JD Long and Paul Teetor

This repo contains the source for the book. You can read the book online at [http://rc2e.com](http://rc2e.com)

[![Build Status](https://travis-ci.org/CerebralMastication/R-Cookbook.svg?branch=master)](https://travis-ci.org/CerebralMastication/R-Cookbook)

You can buy a copy of the book at [Amazon](https://amzn.to/2Y9JVe7) or wherever O'Reilly Books are sold. 

[![R Cookbook Cover](/images_v2/book_cover.jpg)](https://amzn.to/2Y9JVe7)

